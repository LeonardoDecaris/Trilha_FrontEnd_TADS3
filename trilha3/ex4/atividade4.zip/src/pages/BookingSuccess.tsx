const BookingSuccess = () => {
    return (
        <div style={{ textAlign: 'center' }}>
            <h2>Reserva Confirmada!</h2>
            <p>Obrigado por reservar conosco. Sua reserva foi feita com sucesso.</p>
        </div>
    );
}
export default BookingSuccess;
