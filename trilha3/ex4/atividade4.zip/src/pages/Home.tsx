const Home = () => {
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Bem-vindo ao Hotel!</h1>
            <p>Escolha seu quarto ideal.</p>
        </div>
    );
}

export default Home;
